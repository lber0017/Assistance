package com.fit2081.assignmentone

data class Patient(
    val id: String,
    val phoneNumber: String,
    val gender: String,
    val maleScore: Int,
    val femaleScore: Int,
    val vegetablesScore: Int,
    val fruitsScore: Int,
    val grainsScore: Int,
    val wholeGrainsScore: Int,
    val meatScore: Int,
    val dairyScore: Int,
    val waterScore: Int,
    val fatsScore: Int,
    val sodiumScore: Int,
    val sugarScore: Int,
    val alcoholScore: Int,
    val discretionaryScore: Int
) 
package com.fit2081.assignmentone

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader

class CsvReader(private val context: Context) {
    fun readPatientsFromCsv(fileName: String): List<Patient> {
        println("CsvReader - Starting to read CSV file: $fileName")
        val patients = mutableListOf<Patient>()
        
        try {
            context.assets.open(fileName).bufferedReader().useLines { lines ->
                // Skip header
                val iterator = lines.iterator()
                val header = iterator.next()
                println("CsvReader - CSV Header: $header")
                
                iterator.forEach { line ->
                    println("CsvReader - Processing line: $line")
                    val values = line.split(",")
                    println("CsvReader - Split values size: ${values.size}")
                    
                    if (values.size >= 5) {
                        val phoneNumber = values[0]
                        val id = values[1]
                        val gender = values[2]
                        val maleScore = values[3].toIntOrNull() ?: 0
                        val femaleScore = values[4].toIntOrNull() ?: 0
                        
                        // Get individual scores with null safety
                        val vegetablesScore = values.getOrNull(8)?.toIntOrNull() ?: 0
                        val fruitsScore = values.getOrNull(19)?.toIntOrNull() ?: 0
                        val grainsScore = values.getOrNull(28)?.toIntOrNull() ?: 0
                        val wholeGrainsScore = values.getOrNull(32)?.toIntOrNull() ?: 0
                        val meatScore = values.getOrNull(35)?.toIntOrNull() ?: 0
                        val dairyScore = values.getOrNull(39)?.toIntOrNull() ?: 0
                        val sodiumScore = values.getOrNull(42)?.toIntOrNull() ?: 0
                        val alcoholScore = values.getOrNull(45)?.toIntOrNull() ?: 0
                        val waterScore = values.getOrNull(48)?.toIntOrNull() ?: 0
                        val sugarScore = values.getOrNull(54)?.toIntOrNull() ?: 0
                        val fatsScore = values.getOrNull(60)?.toIntOrNull() ?: 0
                        val discretionaryScore = values.getOrNull(5)?.toIntOrNull() ?: 0
                        
                        println("CsvReader - Parsed values for ID $id:")
                        println("CsvReader - Phone: $phoneNumber")
                        println("CsvReader - Gender: $gender")
                        println("CsvReader - Male Score: $maleScore")
                        println("CsvReader - Female Score: $femaleScore")
                        println("CsvReader - Individual scores:")
                        println("CsvReader - Vegetables: $vegetablesScore")
                        println("CsvReader - Fruits: $fruitsScore")
                        println("CsvReader - Grains: $grainsScore")
                        println("CsvReader - Whole Grains: $wholeGrainsScore")
                        println("CsvReader - Meat: $meatScore")
                        println("CsvReader - Dairy: $dairyScore")
                        println("CsvReader - Sodium: $sodiumScore")
                        println("CsvReader - Alcohol: $alcoholScore")
                        println("CsvReader - Water: $waterScore")
                        println("CsvReader - Sugar: $sugarScore")
                        println("CsvReader - Fats: $fatsScore")
                        println("CsvReader - Discretionary: $discretionaryScore")
                        
                        val patient = Patient(
                            id = id,
                            phoneNumber = phoneNumber,
                            gender = gender,
                            maleScore = maleScore,
                            femaleScore = femaleScore,
                            vegetablesScore = vegetablesScore,
                            fruitsScore = fruitsScore,
                            grainsScore = grainsScore,
                            wholeGrainsScore = wholeGrainsScore,
                            meatScore = meatScore,
                            dairyScore = dairyScore,
                            sodiumScore = sodiumScore,
                            alcoholScore = alcoholScore,
                            waterScore = waterScore,
                            sugarScore = sugarScore,
                            fatsScore = fatsScore,
                            discretionaryScore = discretionaryScore
                        )
                        println("CsvReader - Created patient object: $patient")
                        patients.add(patient)
                    } else {
                        println("CsvReader - Skipping line due to insufficient values")
                    }
                }
            }
        } catch (e: Exception) {
            println("CsvReader - Error reading CSV: ${e.message}")
            e.printStackTrace()
        }
        
        println("CsvReader - Finished reading CSV. Total patients: ${patients.size}")
        return patients
    }
} 
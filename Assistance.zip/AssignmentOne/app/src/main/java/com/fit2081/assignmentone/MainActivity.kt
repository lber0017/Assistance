package com.fit2081.assignmentone

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.DatePicker
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.fit2081.assignmentone.ui.theme.AssignmentOneTheme
import java.util.Calendar
import kotlin.Triple
import androidx.compose.material3.TextButton
import androidx.compose.foundation.background
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ButtonDefaults
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.Dp
import androidx.core.graphics.component1
import androidx.core.graphics.component2
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AssignmentOneTheme {
                Surface (
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val navHostController = rememberNavController()

    NavHost(navController = navHostController, startDestination = "home") {
        composable("home") { HomeScreen(navHostController) }
        composable("second") { LoginScreen(navHostController) }
        composable("questionnaire/{userId}") { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId") ?: ""
            QuestionnaireScreen(navHostController, userId)
        }
        composable("dashboard/{userId}") { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId") ?: ""
            DashboardScreen(navHostController, userId)
        }
        composable("insights/{userId}") { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId") ?: ""
            InsightsScreen(navHostController, userId)
        }
    }
}


@Composable
fun HomeScreen(navHostController: NavHostController, modifier: Modifier = Modifier) {
    val context = LocalContext.current
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(100.dp))

            Text(
                text = "NutriTrack",
                fontSize = 40.sp,
                fontWeight =  FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(25.dp))

            androidx.compose.foundation.Image(
                painter = painterResource(id = R.drawable.nutrition_image),
                contentDescription = "Nutrition Logo",
                modifier = Modifier
                    .height(200.dp)
                    .fillMaxWidth()

            )

            Spacer(modifier = Modifier.height(25.dp))

            Text(
                text = "This app provides general health and nutrition information for " +
                        "educational purposes only. It is not intended as medical advice, " +
                        "diagnosis, or treatment. Always consult a qualified healthcare " +
                        "professional before making any changes to your diet, exercise, or " +
                        "health regimen.\n" +
                        "Use this app at your own risk.\n" +
                        "If you'd like to an Accredited Practicing Dietitian (APD), please " +
                        "visit the Monash Nutrition/Dietetics Clinic (discounted rates for " +
                        "students):\n" +
                        "https://www.monash.edu/medicine/scs/nutrition/clinics/nutrition ",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(30.dp))

            Button(
                onClick = {
                    navHostController.navigate("second")
                },
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(50.dp)
            ) {
                Text("Login", fontSize = 20.sp)
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "Designed by Leora Berkovits #3313 7226",
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                color = Color.DarkGray
            )


        }
}

@Composable
fun LoginScreen (navHostController: NavHostController, modifier: Modifier = Modifier) {
    var userID by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val csvReader = remember { CsvReader(context) }
    val patients = remember { 
        val loadedPatients = csvReader.readPatientsFromCsv("nutrition_data.csv")
        println("Loaded patients: $loadedPatients") // Debug log
        loadedPatients
    }
    val patientIds = remember { 
        val ids = patients.map { it.id }
        println("Available IDs: $ids") // Debug log
        ids
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Spacer(modifier = Modifier.height(50.dp))

        Text(
            text = "Log in",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text (
            text = "My ID (Provided by your Clinician)",
            fontSize = 15.sp
        )

        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = userID,
                onValueChange = { userID = it },
                label = { Text("Select your ID from the list") },
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { 
                        println("Dropdown clicked. Available IDs: $patientIds") // Debug log
                        expanded = true 
                    },
                readOnly = true,
                isError = showError,
                trailingIcon = {
                    IconButton(onClick = { 
                        println("Icon clicked. Available IDs: $patientIds") // Debug log
                        expanded = true 
                    }) {
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Select ID"
                        )
                    }
                }
            )

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.fillMaxWidth()
            ) {
                println("Rendering dropdown with IDs: $patientIds") // Debug log
                patientIds.forEach { id ->
                    DropdownMenuItem(
                        text = { Text(id) },
                        onClick = {
                            userID = id
                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text (
            text = "Phone number",
            fontSize = 15.sp
        )

        OutlinedTextField(
            value = phoneNumber,
            onValueChange = { phoneNumber = it },
            label = { Text("Enter Your Number") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
            isError = showError
        )

        if (showError) {
            Text(
                text = errorMessage,
                color = Color.Red,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "This app is only for pre-registered users. " +
                    "Please have your ID and phone number handy " +
                    "before continuing.",
            fontSize = 15.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val isValid = patients.any { it.id == userID && it.phoneNumber == phoneNumber }
                if (isValid) {
                    navHostController.navigate("questionnaire/$userID")
                } else {
                    showError = true
                    errorMessage = "Invalid ID or phone number. Please try again."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Continue")
        }
    }
}

@Composable
fun QuestionnaireScreen(navHostController: NavHostController, userId: String, modifier: Modifier = Modifier) {
    var selectedFoodCategories by remember { mutableStateOf(setOf<String>()) }
    var selectedPersona by remember { mutableStateOf("") }
    var biggestMealTime by remember { mutableStateOf("00:00") }
    var sleepTime by remember { mutableStateOf("00:00") }
    var wakeTime by remember { mutableStateOf("00:00") }
    var showDialog by remember { mutableStateOf(false) }
    var currentPersona by remember { mutableStateOf("") }
    var currentDescription by remember { mutableStateOf("") }
    var currentImage by remember { mutableStateOf(R.drawable.persona_1) }
    var expanded by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    val foodCategories = listOf("Fruits", "Vegetables", "Grains", "Red Meat", "Seafood", "Poultry", "Fish", "Eggs", "Nuts/Seeds")
    val personas = listOf(
        "Health Devotee" to Triple("I'm passionate about healthy eating & health plays a big part in my life...", R.drawable.persona_1, "Health Devotee"),
        "Mindful Eater" to Triple("I am very conscious of what I eat, making sure to balance nutrients...", R.drawable.persona_2, "Mindful Eater"),
        "Wellness Striver" to Triple("I always strive for wellness, eating organic and maintaining a healthy diet...", R.drawable.persona_3, "Wellness Striver"),
        "Balance Seeker" to Triple("I try to eat a balanced diet, but I allow myself to enjoy treats...", R.drawable.persona_4, "Balance Seeker"),
        "Health Procrastinator" to Triple("I plan to eat healthy but often postpone changes...", R.drawable.persona_5, "Health Procrastinator"),
        "Food Carefree" to Triple("I eat whatever I like without thinking too much about health impacts...", R.drawable.persona_6, "Food Carefree")
    )
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "Food Intake Questionnaire",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Text(
            text = "Tick all the food categories you can eat",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(bottom = 4.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(foodCategories) { category ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(end = 2.dp)
                ) {
                    Checkbox(
                        checked = category in selectedFoodCategories,
                        onCheckedChange = {
                            selectedFoodCategories = if (it) selectedFoodCategories + category else selectedFoodCategories - category
                        },
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = category, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Your Persona",
            style = MaterialTheme.typography.bodyLarge,
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 2.dp)
        )

        Text(
            text = "People can be broadly classified into 6 different types based on their eating preferences. Click on each button below to find out the different types, and select the type that best fits you!",
            style = MaterialTheme.typography.bodyMedium,
            fontSize = 11.sp,
            modifier = Modifier.padding(bottom = 2.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp),
            verticalArrangement = Arrangement.spacedBy(1.dp),
            horizontalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            items(personas) { (persona, triple) ->
                Button(
                    onClick = {
                        currentPersona = persona
                        currentDescription = triple.first
                        currentImage = triple.second
                        showDialog = true
                    },
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(2.dp)
                ) {
                    Text(text = persona, fontSize = 9.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = "Which persona best fits you?",
                style = MaterialTheme.typography.bodyLarge,
                fontSize = 14.sp,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = selectedPersona,
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expanded = true },
                    label = { Text("Select your persona") },
                    trailingIcon = {
                        IconButton(onClick = { expanded = true }) {
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Select persona"
                            )
                        }
                    }
                )

                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    personas.forEach { (persona, triple) ->
                        DropdownMenuItem(
                            text = { Text(persona) },
                            onClick = {
                                selectedPersona = persona
                                expanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Timings",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(bottom = 4.dp)
        )

        TimePickerField(
            label = "What time of day approx. do you normally eat your biggest meal?",
            value = biggestMealTime,
            onValueChange = { biggestMealTime = it }
        )

        Spacer(modifier = Modifier.height(4.dp))

        TimePickerField(
            label = "What time of day approx. do you go to sleep at night?",
            value = sleepTime,
            onValueChange = { sleepTime = it }
        )

        Spacer(modifier = Modifier.height(4.dp))

        TimePickerField(
            label = "What time of day approx. do you wake up in the morning?",
            value = wakeTime,
            onValueChange = { wakeTime = it }
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = { 
                navHostController.navigate("dashboard/$userId") {
                    popUpTo("dashboard/$userId") { inclusive = true }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Save")
        }

        Spacer(modifier = Modifier.height(8.dp))
    }

    if (showDialog) {
        PersonaSelectionDialog(
            personaName = currentPersona,
            description = currentDescription,
            imageRes = currentImage,
            onDismiss = { showDialog = false }
        )
    }
}

@Composable
fun PersonaSelectionDialog(
    personaName: String,
    description: String,
    imageRes: Int,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Image(
                    painter = painterResource(id = imageRes),
                    contentDescription = personaName,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                )
                Text(text = personaName, style = MaterialTheme.typography.headlineSmall)
            }
        },
        text = { Text(text = description) },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text(text = "Dismiss")
            }
        }
    )
}

@Composable
fun TimePickerField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    val context = LocalContext.current
    val calendar = Calendar.getInstance()
    
    val timePickerDialog = remember {
        TimePickerDialog(
            context,
            { _, hour, minute ->
                println("Time selected: $hour:$minute") // Debug log
                onValueChange(String.format("%02d:%02d", hour, minute))
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true // 24 hour format
        )
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            fontSize = 12.sp,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        OutlinedTextField(
            value = value,
            onValueChange = { },
            readOnly = true,
            modifier = Modifier
                .width(120.dp)
                .height(56.dp)
                .clickable { 
                    println("Time field clicked") // Debug log
                    timePickerDialog.show()
                },
            label = { Text("Select time") },
            textStyle = MaterialTheme.typography.bodyLarge,
            trailingIcon = {
                IconButton(
                    onClick = { 
                        println("Time field icon clicked") // Debug log
                        timePickerDialog.show()
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Select time"
                    )
                }
            }
        )
    }
}

@Composable
fun DatePickerField(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val calendar = Calendar.getInstance()
    
    val datePickerDialog = DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            calendar.set(year, month, dayOfMonth)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = "${calendar.get(Calendar.YEAR)}-${calendar.get(Calendar.MONTH) + 1}-${calendar.get(Calendar.DAY_OF_MONTH)}",
            onValueChange = { },
            readOnly = true,
            modifier = Modifier
                .width(120.dp)
                .clickable { datePickerDialog.show() },
            label = { Text("Select date") }
        )
        Button(
            onClick = { datePickerDialog.show() },
            modifier = Modifier.width(50.dp)
        ) {
            Text("Select")
        }
    }
}

@Composable
fun DashboardScreen(navHostController: NavHostController, userId: String) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf(
        "Home" to R.drawable.home_icon,
        "Insights" to R.drawable.insights_icon,
        "NutriCoach" to R.drawable.nutricoach_icon,
        "Settings" to R.drawable.settings_icon
    )

    val context = LocalContext.current
    val csvReader = remember { CsvReader(context) }
    val patients = remember { 
        val loadedPatients = csvReader.readPatientsFromCsv("nutrition_data.csv")
        println("Dashboard - Loaded patients: $loadedPatients")
        loadedPatients
    }
    
    // Get the current patient's data from the same row as their login credentials
    val currentPatient = remember { 
        val patient = patients.find { it.id == userId }
        println("Dashboard - Current patient for ID $userId: $patient")
        if (patient == null) {
            println("Dashboard - No patient found for ID: $userId")
        } else {
            println("Dashboard - Found patient: $patient")
            println("Dashboard - Patient gender: ${patient.gender}")
            println("Dashboard - Male score: ${patient.maleScore}")
            println("Dashboard - Female score: ${patient.femaleScore}")
        }
        patient
    }

    // Calculate the food score based on gender
    val foodScore = remember {
        val score = currentPatient?.let { patient ->
            when (patient.gender.trim().lowercase()) {
                "male" -> {
                    println("Dashboard - Using male score: ${patient.maleScore}")
                    patient.maleScore.toInt()
                }
                "female" -> {
                    println("Dashboard - Using female score: ${patient.femaleScore}")
                    patient.femaleScore.toInt()
                }
                else -> {
                    println("Dashboard - Unknown gender: ${patient.gender}, defaulting to 0")
                    0
                }
            }
        } ?: 0
        println("Dashboard - Final food score: $score")
        score
    }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp)
        ) {
            Column {
                Spacer(modifier = Modifier.height(80.dp))
                
                // Header Section
                Text(
                    text = "Hello,",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.Gray,
                    fontSize = 30.sp
                )
                Text(
                    text = userId,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "You've already filled in your Food Intake Questionnaire, but you can change details here.",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { navHostController.navigate("questionnaire/$userId") },
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                        Text("Edit")
                    }
                }

                // Food Image
                Image(
                    painter = painterResource(id = R.drawable.food_plate),
                    contentDescription = "Food plate",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .padding(vertical = 16.dp)
                )

                Spacer(modifier = Modifier.height(40.dp))

                // Score Section
                Text(
                    text = "My Score",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowUp,
                            contentDescription = "Score trend",
                            modifier = Modifier.size(24.dp)
                        )
                        Column(modifier = Modifier.padding(start = 8.dp)) {
                            Text(
                                text = "Your Food Quality score",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "$foodScore/100",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color(0xFF4CAF50)
                            )
                        }
                    }
                    TextButton(onClick = { /* Navigate to detailed scores */ }) {
                        Text("See all scores")
                        Icon(Icons.Default.MoreVert, contentDescription = "See more")
                    }
                }

                // Explanation Section
                Text(
                    text = "What is the Food Quality Score?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 16.dp)
                )
                Text(
                    text = "Your Food Quality Score provides a snapshot of how well your eating patterns align with established food guidelines, helping you identify both strengths and opportunities for improvement in your diet.\n\nThis personalized measurement considers various food groups including vegetables, fruits, whole grains, and proteins to give you practical insights for making healthier food choices.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        }

        // Bottom Navigation Bar
        NavigationBar {
            tabs.forEachIndexed { index, (title, iconRes) ->
                NavigationBarItem(
                    icon = { 
                        Image(
                            painter = painterResource(id = iconRes),
                            contentDescription = title,
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = { Text(title) },
                    selected = selectedTab == index,
                    onClick = { 
                        selectedTab = index
                        when (index) {
                            0 -> {} // Already on dashboard
                            1 -> navHostController.navigate("insights/$userId")
                            // Add other navigation cases as needed
                        }
                    }
                )
            }
        }
    }
}


@Composable
fun ScoreProgressBar(
    score: Int,
    maxScore: Int,
    modifier: Modifier = Modifier,
    height: Dp = 4.dp,
    backgroundColor: Color = Color(0xFFE0E0E0),
    foregroundColor: Color = Color(0xFF6200EE)
) {
    val progress = score.toFloat() / maxScore.toFloat()
    
    Box(
        modifier = modifier
            .height(height + 12.dp)
            .padding(vertical = 6.dp)
    ) {
        // Background track
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(height)
                .background(backgroundColor, CircleShape)
                .align(Alignment.Center)
        )
        
        // Progress bar
        Box(
            modifier = Modifier
                .fillMaxWidth(progress)
                .height(height)
                .background(foregroundColor, CircleShape)
                .align(Alignment.Center)
        )
        
        // Slider circle with border
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(Color.White, CircleShape)
                .border(2.dp, foregroundColor, CircleShape)
                .align(Alignment.CenterStart)
        )
    }
}

@Composable
fun InsightsScreen(navHostController: NavHostController, userId: String) {
    var selectedTab by remember { mutableStateOf(1) }
    var showShareDialog by remember { mutableStateOf(false) }
    var showImproveDialog by remember { mutableStateOf(false) }
    
    val tabs = listOf(
        "Home" to R.drawable.home_icon,
        "Insights" to R.drawable.insights_icon,
        "NutriCoach" to R.drawable.nutricoach_icon,
        "Settings" to R.drawable.settings_icon
    )

    val context = LocalContext.current
    val csvReader = remember { CsvReader(context) }
    val patients = remember { 
        csvReader.readPatientsFromCsv("nutrition_data.csv")
    }
    
    val currentPatient = remember { 
        patients.find { it.id == userId }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "Insights: Food Score",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 16.dp)
                )

                // Food Categories Scores
                val categories = listOf(
                    Pair("Vegetables", Pair(currentPatient?.vegetablesScore ?: 0, 10)),
                    Pair("Fruits", Pair(currentPatient?.fruitsScore ?: 0, 10)),
                    Pair("Grains & Cereals", Pair(currentPatient?.grainsScore ?: 0, 10)),
                    Pair("Whole Grains", Pair(currentPatient?.wholeGrainsScore ?: 0, 10)),
                    Pair("Meat & Alternatives", Pair(currentPatient?.meatScore ?: 0, 10)),
                    Pair("Dairy", Pair(currentPatient?.dairyScore ?: 0, 10)),
                    Pair("Water", Pair(currentPatient?.waterScore ?: 0, 5)),
                    Pair("Unsaturated Fats", Pair(currentPatient?.fatsScore ?: 0, 10)),
                    Pair("Sodium", Pair(currentPatient?.sodiumScore ?: 0, 10)),
                    Pair("Sugar", Pair(currentPatient?.sugarScore ?: 0, 10)),
                    Pair("Alcohol", Pair(currentPatient?.alcoholScore ?: 0, 5)),
                    Pair("Discretionary Foods", Pair(currentPatient?.discretionaryScore ?: 0, 10))
                )

                categories.forEach { categoryPair ->
                    val category = categoryPair.first
                    val scoreData = categoryPair.second
                    val score = scoreData.first
                    val maxScore = scoreData.second
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = category,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.weight(1f)
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(2f)
                        ) {
                            ScoreProgressBar(
                                score = score,
                                maxScore = maxScore,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "$score/$maxScore",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Total Food Quality Score
                Text(
                    text = "Total Food Quality Score",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                val totalScore = currentPatient?.let { patient ->
                    when (patient.gender.trim().lowercase()) {
                        "male" -> patient.maleScore.toInt()
                        "female" -> patient.femaleScore.toInt()
                        else -> 0
                    }
                } ?: 0

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ScoreProgressBar(
                        score = totalScore,
                        maxScore = 100,
                        modifier = Modifier.weight(1f),
                        height = 8.dp
                    )
                    Text(
                        text = "$totalScore/100",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Action Buttons
                Button(
                    onClick = { showShareDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6200EE))
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Text(text = "Share with someone")
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { /* Do nothing */ },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6200EE))
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowUp,
                        contentDescription = "Improve",
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Text(text = "Improve my diet!")
                }
            }
        }

        // Bottom Navigation Bar
        NavigationBar {
            tabs.forEachIndexed { index, (title, iconRes) ->
                NavigationBarItem(
                    icon = { 
                        Image(
                            painter = painterResource(id = iconRes),
                            contentDescription = title,
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = { Text(text = title) },
                    selected = selectedTab == index,
                    onClick = { 
                        selectedTab = index
                        when (index) {
                            0 -> navHostController.navigate("dashboard/$userId")
                            1 -> {} // Already on insights
                            // Add other navigation cases as needed
                        }
                    }
                )
            }
        }
    }

    if (showShareDialog) {
        AlertDialog(
            onDismissRequest = { showShareDialog = false },
            title = { Text(text = "Share Food Score") },
            text = { 
                Text(
                    text = "Your Food Quality Score and detailed breakdown can help others understand their own nutritional goals. Would you like to share your results?"
                )
            },
            confirmButton = {
                Button(onClick = {
                    val shareIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        type = "text/plain"
                        val totalScore = currentPatient?.let { patient ->
                            when (patient.gender.trim().lowercase()) {
                                "male" -> patient.maleScore.toInt()
                                "female" -> patient.femaleScore.toInt()
                                else -> 0
                            }
                        } ?: 0
                        putExtra(Intent.EXTRA_TEXT, """
                            Check out my Food Quality Score!
                            Total Score: $totalScore/100
                            
                            Breakdown:
                            Vegetables: ${currentPatient?.vegetablesScore}/10
                            Fruits: ${currentPatient?.fruitsScore}/10
                            Grains: ${currentPatient?.grainsScore}/10
                            Whole Grains: ${currentPatient?.wholeGrainsScore}/10
                            Meat & Alternatives: ${currentPatient?.meatScore}/10
                            Dairy: ${currentPatient?.dairyScore}/10
                            Water: ${currentPatient?.waterScore}/5
                            Unsaturated Fats: ${currentPatient?.fatsScore}/10
                            Sodium: ${currentPatient?.sodiumScore}/10
                            Sugar: ${currentPatient?.sugarScore}/10
                            Alcohol: ${currentPatient?.alcoholScore}/5
                            Discretionary Foods: ${currentPatient?.discretionaryScore}/10
                            
                            Track your nutrition with NutriTrack!
                        """.trimIndent())
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share via"))
                    showShareDialog = false
                }) {
                    Text(text = "Share")
                }
            },
            dismissButton = {
                Button(onClick = { showShareDialog = false }) {
                    Text(text = "Cancel")
                }
            }
        )
    }

    if (showImproveDialog) {
        AlertDialog(
            onDismissRequest = { showImproveDialog = false },
            title = { Text(text = "Improve Your Diet") },
            text = { 
                Column {
                    Text(text = "Based on your scores, here are some suggestions:")
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    val scores = listOf(
                        "Vegetables" to (currentPatient?.vegetablesScore ?: 0),
                        "Fruits" to (currentPatient?.fruitsScore ?: 0),
                        "Grains" to (currentPatient?.grainsScore ?: 0),
                        "Whole Grains" to (currentPatient?.wholeGrainsScore ?: 0),
                        "Meat & Alternatives" to (currentPatient?.meatScore ?: 0),
                        "Dairy" to (currentPatient?.dairyScore ?: 0),
                        "Water" to (currentPatient?.waterScore?.times(2) ?: 0),
                        "Unsaturated Fats" to (currentPatient?.fatsScore ?: 0),
                        "Sodium" to (currentPatient?.sodiumScore ?: 0),
                        "Sugar" to (currentPatient?.sugarScore ?: 0),
                        "Alcohol" to (currentPatient?.alcoholScore?.times(2) ?: 0),
                        "Discretionary Foods" to (currentPatient?.discretionaryScore ?: 0)
                    ).sortedBy { it.second }

                    scores.take(3).forEach { (category, score) ->
                        Text(text = "• Improve your $category intake (current score: $score/10)")
                        val suggestionText = when (category) {
                            "Vegetables" -> "  Try adding an extra serving of vegetables to your main meals"
                            "Fruits" -> "  Include fruits as snacks throughout the day"
                            "Grains" -> "  Choose whole grain options when possible"
                            "Whole Grains" -> "  Replace refined grains with whole grain alternatives"
                            "Meat & Alternatives" -> "  Include lean proteins and legumes in your diet"
                            "Dairy" -> "  Add low-fat dairy products to your daily routine"
                            "Water" -> "  Set reminders to drink water throughout the day"
                            "Unsaturated Fats" -> "  Include healthy fats like avocados and nuts"
                            "Sodium" -> "  Reduce processed foods and added salt"
                            "Sugar" -> "  Cut back on sugary drinks and desserts"
                            "Alcohol" -> "  Limit alcoholic beverages and alternate with water"
                            else -> "  Choose whole foods over processed snacks"
                        }
                        Text(text = suggestionText)
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showImproveDialog = false }) {
                    Text(text = "Got it!")
                }
            }
        )
    }
}
